const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { Telegraf } = require('telegraf');
const { Pool } = require('pg');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const BOT_TOKEN = process.env.BOT_TOKEN;
const BOT_USERNAME = process.env.BOT_USERNAME || 'ssx_bot';
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const bot = new Telegraf(BOT_TOKEN);

async function ensureUser(ctx, telegramId) {
  const username = ctx.from && ctx.from.username ? ctx.from.username : null;
  const referralCode = `REF${telegramId}`;
  const q = `INSERT INTO users (telegram_id, username, referral_code) VALUES ($1, $2, $3) ON CONFLICT (telegram_id) DO NOTHING`;
  await pool.query(q, [telegramId, username, referralCode]);
}

bot.start(async (ctx) => {
  const telegramId = ctx.from.id;
  await ensureUser(ctx, telegramId);
  ctx.reply(`Welcome ${ctx.from.first_name || 'there'}! Your referral: REF${telegramId}`);
});

bot.command('referral', async (ctx) => {
  const code = `REF${ctx.from.id}`;
  ctx.reply(`Share this link: t.me/${BOT_USERNAME}?start=${code}`);
});

bot.command('leaderboard', async (ctx) => {
  const res = await pool.query('SELECT username, points FROM users ORDER BY points DESC LIMIT 10');
  if (res.rows.length === 0) return ctx.reply('No users yet.');
  const text = res.rows.map((r,i)=>`${i+1}. ${r.username||'anon'} — ${r.points} pts`).join('\n');
  ctx.reply(`🏆 Leaderboard:\n${text}`);
});

app.get('/api/leaderboard', async (req, res) => {
  const result = await pool.query('SELECT username, points, referral_code FROM users ORDER BY points DESC LIMIT 100');
  res.json(result.rows);
});

(async ()=>{
  try { await pool.query('SELECT 1'); console.log('DB connected'); } 
  catch(e){ console.error('DB fail', e); }
  bot.launch();
  const port = process.env.PORT || 3000;
  app.listen(port, ()=>console.log('API listening on', port));
})();

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));